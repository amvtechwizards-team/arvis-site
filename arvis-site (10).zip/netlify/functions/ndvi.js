// Netlify Function: fetches MODIS NDVI (MOD13Q1) from NASA ORNL DAAC on the server,
// so the browser never talks to modis.ornl.gov directly (avoids browser blocks).
// Endpoint: /.netlify/functions/ndvi?lat=10.4&lon=76.11
const BASE = "https://modis.ornl.gov/rst/api/v1/MOD13Q1/subset";
const DAY = 864e5;

function compositeCode(year, doy) {
  return "A" + year + String(doy).padStart(3, "0");
}
function dateFromYearDoy(year, doy) {
  return new Date(Date.UTC(year, 0, 1) + (doy - 1) * DAY);
}
// MOD13Q1 composites start on day 1, 17, 33, ... of each year (16-day steps)
function compositeStarts(year) {
  const out = [];
  for (let d = 1; d <= 353; d += 16) out.push({ year, doy: d });
  return out;
}

async function ndviAt(lat, lon, year, doy) {
  const code = compositeCode(year, doy);
  const url = `${BASE}?latitude=${lat}&longitude=${lon}&startDate=${code}&endDate=${code}&kmAboveBelow=1&kmLeftRight=1`;
  const r = await fetch(url, { headers: { Accept: "application/json" } });
  if (!r.ok) throw new Error("NASA ORNL DAAC returned HTTP " + r.status);
  const j = await r.json();
  const band = (j.subset || []).find((b) => b.band === "250m_16_days_NDVI");
  if (!band || !Array.isArray(band.data)) return null;
  const c = band.data[Math.floor(band.data.length / 2)]; // centre pixel of the subset
  if (c == null || c < -2000 || c > 10000) return null; // fill / invalid values
  return c * 0.0001; // MOD13Q1 NDVI scale factor
}

exports.handler = async (event) => {
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Cache-Control": "public, max-age=3600",
  };
  const lat = parseFloat((event.queryStringParameters || {}).lat);
  const lon = parseFloat((event.queryStringParameters || {}).lon);
  if (!isFinite(lat) || !isFinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: "Invalid coordinates" }) };
  }

  try {
    // latest composite that is at least 10 days old (processing lag)
    const cutoff = new Date(Date.now() - 10 * DAY);
    const Y = cutoff.getUTCFullYear();
    const startOfYear = Date.UTC(Y, 0, 1);
    const doyNow = Math.floor((cutoff.getTime() - startOfYear) / DAY) + 1;
    const latestDoy = Math.floor((doyNow - 1) / 16) * 16 + 1;

    // last 12 composites up to the latest one
    const all = [...compositeStarts(Y - 1), ...compositeStarts(Y)].filter(
      (c) => c.year * 1000 + c.doy <= Y * 1000 + latestDoy
    );
    const recent = all.slice(-12);

    const recentVals = await Promise.all(recent.map((c) => ndviAt(lat, lon, c.year, c.doy).catch(() => null)));
    const baseVals = await Promise.all(
      [1, 2, 3, 4, 5].map((k) => ndviAt(lat, lon, Y - k, latestDoy).catch(() => null))
    );

    const series = recent
      .map((c, i) => ({ d: dateFromYearDoy(c.year, c.doy).toISOString().slice(0, 10), v: recentVals[i] }))
      .filter((p) => p.v != null);
    if (!series.length) {
      return { statusCode: 502, headers, body: JSON.stringify({ error: "No valid NDVI pixels returned for this location" }) };
    }
    const latest = series[series.length - 1];
    const baseList = baseVals.filter((v) => v != null);
    const base = baseList.length ? baseList.reduce((a, b) => a + b, 0) / baseList.length : null;

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        val: Math.round(latest.v * 100) / 100,
        base: base == null ? null : Math.round(base * 100) / 100,
        hist: series.map((p) => Math.round(p.v * 1000) / 1000),
        full: series.map((p) => ({ d: p.d, v: Math.round(p.v * 1000) / 1000 })),
        range: series[0].d + " to " + latest.d + " (16-day composites, centre pixel)",
        src: "MODIS MOD13Q1 via NASA ORNL DAAC",
      }),
    };
  } catch (e) {
    return { statusCode: 502, headers, body: JSON.stringify({ error: e.message || "NDVI request failed" }) };
  }
};
